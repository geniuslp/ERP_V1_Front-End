import React from 'react'
import { Button } from 'antd'
import type { ButtonProps } from 'antd'
import PermissionGate from '@/components/permission/PermissionGate'
import type { PermissionAction } from '@/types'

interface PermissionButtonProps extends ButtonProps {
  menuCode: string
  action: PermissionAction
  mode?: 'hide' | 'disable'
}

const PermissionButton: React.FC<PermissionButtonProps> = ({ menuCode, action, mode = 'hide', ...buttonProps }) => (
  <PermissionGate menuCode={menuCode} action={action} mode={mode}>
    <Button {...buttonProps} />
  </PermissionGate>
)

export default PermissionButton
