import React, { useEffect, useRef, useState } from 'react'
import { Card, Table, Button, Space, Tooltip, Input, Select, Tag, Popconfirm, message, Modal } from 'antd'
import {
  PlusOutlined, SearchOutlined, ReloadOutlined,
  EditOutlined, DeleteOutlined, QrcodeOutlined, UploadOutlined,
} from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Html5Qrcode } from 'html5-qrcode'
import PageHeader from '@/components/common/PageHeader'
import PermissionButton from '@/components/common/PermissionButton'
import { useAppSelector } from '@/store'
import { mockStockItems } from '@/utils/mockStockData'
import type { StockItem, ItemType } from '@/types/stock'

const MENU_CODE = 'stock-items'

const BASE_URL = (import.meta as any).env?.VITE_API_URL

const cardStyle: React.CSSProperties = {
  borderRadius: 12,
  border: 'none',
  boxShadow: '0 2px 12px rgba(15,45,94,0.08)',
}

const StockItemListPage: React.FC = () => {
  const navigate = useNavigate()
  const accessToken = useAppSelector((s) => s.auth.tokens?.accessToken)
  const fileRef = useRef<HTMLInputElement>(null)
  const [data, setData] = useState<StockItem[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [itemType, setItemType] = useState<ItemType | undefined>()
  const [isActive, setIsActive] = useState<boolean | undefined>()

  const [scanModal, setScanModal] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [scanError, setScanError] = useState<string | null>(null)
  const scannerRef = useRef<any>(null)
  const scanDivId = 'qr-reader'

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await axios.get(`${BASE_URL}/stock/items`, {
        headers: { Authorization: `Bearer ${accessToken}` },
        params: { search: search || undefined, item_type: itemType, is_active: isActive, page_size: 100 },
      })
      const raw = Array.isArray(res.data) ? res.data : res.data?.data
      setData(Array.isArray(raw) ? raw : [])
    } catch {
      setData(mockStockItems)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`${BASE_URL}/stock/items/${id}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
      message.success('Item deleted')
      fetchData()
    } catch (err: any) {
      message.error(err?.response?.data?.message || err?.message || 'Delete failed')
    }
  }

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const formData = new FormData()
    formData.append('file', file)
    try {
      const res = await axios.post(`${BASE_URL}/stock/items/import`, formData, {
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'multipart/form-data' },
      })
      message.success(`Imported ${res.data?.count ?? 0} items`)
      fetchData()
    } catch (err: any) {
      message.error(err?.response?.data?.message || err?.message || 'Import failed')
    } finally {
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const handleReset = () => {
    setSearch('')
    setItemType(undefined)
    setIsActive(undefined)
  }

  const stopScanner = async () => {
    try {
      if (scannerRef.current) {
        await scannerRef.current.stop()
        scannerRef.current = null
      }
    } catch {}
    setScanning(false)
  }

  const handleQRDetected = async (itemCode: string) => {
    await stopScanner()
    setScanModal(false)

    const found = data.find(
      (item) => item.itemCode === itemCode || item.qrCode === itemCode
    )
    if (found) {
      navigate(`/stock/items/${found.id}/edit`)
      return
    }

    try {
      const res = await axios.get(`${BASE_URL}/stock/items`, {
        headers: { Authorization: `Bearer ${accessToken}` },
        params: { search: itemCode, page_size: 1 },
      })
      const raw = Array.isArray(res.data) ? res.data : res.data?.data ?? []
      const items = Array.isArray(raw) ? raw : []
      if (items.length > 0) {
        navigate(`/stock/items/${items[0].id}/edit`)
      } else {
        message.warning(`ไม่พบ item สำหรับ QR: ${itemCode}`)
      }
    } catch {
      message.error('ค้นหา item ไม่สำเร็จ')
    }
  }

  const startScanner = async () => {
    setScanning(true)
    setScanError(null)
    try {
      const scanner = new Html5Qrcode(scanDivId)
      scannerRef.current = scanner
      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        (decodedText) => {
          handleQRDetected(decodedText)
        },
        undefined
      )
    } catch (err: any) {
      setScanError('ไม่สามารถเปิดกล้องได้ — ' + (err?.message ?? err))
      setScanning(false)
    }
  }

  const openScanModal = () => {
    setScanModal(true)
    setScanError(null)
  }

  const closeScanModal = async () => {
    await stopScanner()
    setScanModal(false)
  }

  useEffect(() => {
    if (scanModal) {
      setTimeout(() => startScanner(), 300)
    }
    return () => {
      stopScanner()
    }
  }, [scanModal])

  useEffect(() => { fetchData() }, [search, itemType, isActive])

  const columns = [
    {
      title: 'Item Code',
      dataIndex: 'itemCode',
      key: 'itemCode',
      render: (code: string, record: StockItem) => (
        <a style={{ color: '#2563eb', fontWeight: 600 }} onClick={() => navigate(`/stock/items/${record.id}/edit`)}>
          {code}
        </a>
      ),
    },
    { title: 'Item Name', dataIndex: 'itemName', key: 'itemName', ellipsis: true },
    {
      title: 'Category',
      dataIndex: 'categoryName',
      key: 'categoryName',
      render: (val?: string) => val || <span style={{ color: '#9ca3af' }}>—</span>,
    },
    {
      title: 'Type',
      dataIndex: 'itemType',
      key: 'itemType',
      render: (val: ItemType) => (
        <Tag color={val === 'returnable' ? 'blue' : 'orange'}>
          {val === 'returnable' ? 'Returnable' : 'Consumable'}
        </Tag>
      ),
    },
    { title: 'Unit', dataIndex: 'unit', key: 'unit' },
    { title: 'Min Qty', dataIndex: 'minQty', key: 'minQty', align: 'right' as const },
    {
      title: 'Status',
      dataIndex: 'isActive',
      key: 'isActive',
      render: (val: boolean) => <Tag color={val ? 'green' : 'default'}>{val ? 'Active' : 'Inactive'}</Tag>,
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 130,
      render: (_: any, record: StockItem) => (
        <Space>
          <Tooltip title="Edit">
            <PermissionButton menuCode={MENU_CODE} action="edit" size="small" icon={<EditOutlined />} onClick={() => navigate(`/stock/items/${record.id}/edit`)} />
          </Tooltip>
          <Tooltip title="QR Code">
            <Button size="small" icon={<QrcodeOutlined />} onClick={() => navigate(`/stock/qrcode?item=${record.itemCode}`)} />
          </Tooltip>
          <Popconfirm title="Delete this item?" okText="Delete" cancelText="Cancel" onConfirm={() => handleDelete(record.id)}>
            <Tooltip title="Delete">
              <PermissionButton menuCode={MENU_CODE} action="delete" size="small" danger icon={<DeleteOutlined />} />
            </Tooltip>
          </Popconfirm>
        </Space>
      ),
    },
  ]

  return (
    <div>
      <input ref={fileRef} type="file" accept=".xlsx,.xls" style={{ display: 'none' }} onChange={handleImport} />
      <PageHeader
        title="Item Master"
        subtitle="Manage stock item catalog"
        breadcrumbs={[{ title: 'Home' }, { title: 'Stock Management' }, { title: 'Item Master' }]}
        extra={
          <Space>
            <Button
              icon={<QrcodeOutlined />}
              onClick={openScanModal}
            >
              Scan QR
            </Button>
            <PermissionButton menuCode={MENU_CODE} action="write" icon={<UploadOutlined />} onClick={() => fileRef.current?.click()}>Import Excel</PermissionButton>
            <PermissionButton
              menuCode={MENU_CODE}
              action="write"
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => navigate('/stock/items/create')}
              style={{ background: 'linear-gradient(135deg, #2563eb, #1d4ed8)', border: 'none', boxShadow: '0 4px 16px rgba(37,99,235,0.4)' }}
            >
              Add Item
            </PermissionButton>
          </Space>
        }
      />
      <Card style={cardStyle}>
        <Space style={{ marginBottom: 16, flexWrap: 'wrap' }}>
          <Input
            placeholder="Search item code / name"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onPressEnter={fetchData}
            style={{ width: 220 }}
            allowClear
          />
          <Select
            placeholder="Item Type"
            value={itemType}
            onChange={setItemType}
            allowClear
            style={{ width: 150 }}
            options={[
              { value: 'returnable', label: 'Returnable' },
              { value: 'consumable', label: 'Consumable' },
            ]}
          />
          <Select
            placeholder="Status"
            value={isActive}
            onChange={setIsActive}
            allowClear
            style={{ width: 130 }}
            options={[
              { value: true, label: 'Active' },
              { value: false, label: 'Inactive' },
            ]}
          />
          <Button type="primary" icon={<SearchOutlined />} onClick={fetchData}>Search</Button>
          <Button icon={<ReloadOutlined />} onClick={handleReset}>Reset</Button>
        </Space>
        <Table
          rowKey="id"
          loading={loading}
          columns={columns}
          dataSource={data}
          pagination={{ pageSize: 20, showTotal: (t) => `Total ${t} items` }}
          locale={{ emptyText: 'No items found' }}
        />
      </Card>

      <Modal
        title={
          <Space>
            <QrcodeOutlined style={{ color: '#2563eb' }} />
            <span>Scan QR Code</span>
          </Space>
        }
        open={scanModal}
        onCancel={closeScanModal}
        footer={null}
        width={380}
        centered
        destroyOnClose
      >
        <div style={{ textAlign: 'center' }}>
          <div
            id={scanDivId}
            style={{
              width: '100%',
              borderRadius: 12,
              overflow: 'hidden',
              background: '#000',
              minHeight: 280,
            }}
          />

          {scanError && (
            <div style={{
              marginTop: 12,
              padding: '8px 12px',
              background: '#fef2f2',
              border: '0.5px solid #fecaca',
              borderRadius: 8,
              color: '#dc2626',
              fontSize: 13,
            }}>
              {scanError}
            </div>
          )}

          <div style={{ marginTop: 12, fontSize: 13, color: '#64748b' }}>
            {scanning
              ? '🎥 กล้องกำลังทำงาน — นำ QR Code เข้ามาในกรอบ'
              : scanError
              ? 'กล้องไม่พร้อมใช้งาน'
              : 'กำลังเปิดกล้อง...'}
          </div>

          <Button
            style={{ marginTop: 16 }}
            onClick={closeScanModal}
          >
            Cancel
          </Button>
        </div>
      </Modal>
    </div>
  )
}

export default StockItemListPage
